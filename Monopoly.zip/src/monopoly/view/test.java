package monopoly.view;

public class test {
	private int money;
	
	public test() {
		
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}
}
